test = {   'name': 'q1_13',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> # Check your column labels and spelling;\n>>> region_counts.labels == ('region', 'count')\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> # Counts must sum to 50;\n>>> sum(region_counts.column('count')) == 50\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
