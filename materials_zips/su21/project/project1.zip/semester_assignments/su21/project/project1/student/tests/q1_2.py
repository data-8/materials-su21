test = {   'name': 'q1_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> first = round(h_decade_growth.sort(0).column(2).item(0), 8);\n>>> 0.005 <= first <= 0.5\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Compute the annual exponential growth rate;\n>>> max(h_decade_growth.column(2)) < 0.03\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
