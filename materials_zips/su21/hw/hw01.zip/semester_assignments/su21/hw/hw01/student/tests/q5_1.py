test = {   'name': 'q5_1',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> isinstance(biggest_change, (int, float))\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
