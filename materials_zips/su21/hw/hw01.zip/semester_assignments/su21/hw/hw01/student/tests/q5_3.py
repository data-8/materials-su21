test = {   'name': 'q5_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(gws_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(linguistics_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(rhetoric_relative_change, (int, float))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
