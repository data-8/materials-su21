test = {'name': 'q131', 'points': 1, 'suites': [{'cases': [{'code': '>>> sentence_length\n896', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
