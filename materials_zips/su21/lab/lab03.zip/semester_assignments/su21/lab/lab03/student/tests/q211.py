test = {   'name': 'q211',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np;\n>>> type(interesting_numbers) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(interesting_numbers)\n5', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np;\n>>> all(interesting_numbers == np.array([0, 1, -1, math.pi, math.e]))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
