test = {   'name': 'q11',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> woman_asking\n'The woman asked:'", 'hidden': False, 'locked': False},
                                   {'code': '>>> gagarin_quote\n\'"As a matter of fact, I have!"\'', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
