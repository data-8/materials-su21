test = {   'name': 'q43',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> num_even_year_movies == 127\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
