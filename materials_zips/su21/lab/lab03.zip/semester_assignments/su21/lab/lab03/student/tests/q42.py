test = {   'name': 'q42',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> abs(before_2000 - 8.2783625730994146) < 1e-5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(after_or_in_2000 - 8.2379746835443033) < 1e-5\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
