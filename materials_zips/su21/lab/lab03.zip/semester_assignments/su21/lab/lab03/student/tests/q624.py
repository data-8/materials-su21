test = {   'name': 'q624',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> all(powers_of_2 == 2 ** np.arange(30))\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
