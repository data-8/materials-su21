test = {   'name': 'q8_1',
    'points': [1],
    'suites': [{'cases': [{'code': '>>> survey == "feeling datagr8"\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
